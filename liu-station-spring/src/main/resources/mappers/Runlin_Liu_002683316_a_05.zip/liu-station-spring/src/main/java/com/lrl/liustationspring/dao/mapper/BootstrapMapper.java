package com.lrl.liustationspring.dao.mapper;

public interface BootstrapMapper {

    void createEnvironment();
}
