The service layer is totally my creation where no Spring pattern was used.

Including how the controllers call the services and how the services call the DAOs.

I'm not going to try to spend more time on the complex structure of Spring. As long as the system works, I'm not going
to modify this layer.

But DAOs and controllers now look good enough to operate.