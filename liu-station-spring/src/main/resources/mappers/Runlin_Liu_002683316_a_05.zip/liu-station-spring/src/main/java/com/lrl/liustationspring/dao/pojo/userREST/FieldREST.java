package com.lrl.liustationspring.dao.pojo.userREST;

public abstract class FieldREST{
}
