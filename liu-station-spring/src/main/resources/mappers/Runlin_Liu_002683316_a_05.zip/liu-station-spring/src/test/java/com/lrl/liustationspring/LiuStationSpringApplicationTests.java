package com.lrl.liustationspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiuStationSpringApplicationTests {

    @Test
    void contextLoads() {
    }

}
